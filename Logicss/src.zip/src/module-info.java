/**
 * 
 */
/**
 * 
 */
module Logicss {
}